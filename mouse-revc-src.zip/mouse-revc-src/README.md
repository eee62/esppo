# ESP32-S31 Vision Pro — Rev C

Rev C of the ESP32-S31 Vision Pro board: chord power-on with two 6 × 6 mm keys, and a 1.0 A charger sized for a 1S LiPo of up to 3000 mAh.
It was built from Rev B (`../ESP32-S31-Vision-Pro/`, untouched). Details: `RevC_CHANGES.md`. Netlist spec: `rev_c_chord_power_on.md`.

**Not ordered.** The package is ready to upload to JLCPCB, but nothing has been ordered or put in a cart.

## Status

| Check | Result |
|---|---|
| ERC | 0 errors, 0 warnings (Rev B: 0 / 0) |
| DRC | 0 violations, 0 unconnected, 0 schematic-parity issues (Rev B: 0 / 0) |
| Tamper loop | 148 / 148 items identical to Rev B, continuous, Tamper class 0.30 mm clearance passes (nearest new copper 0.71 mm) |
| Outline / holes / RF keep-out | identical to Rev B (60.0 × 58.0 mm, R 2.0, 4 × M2.5) |
| SMT side | all parts on top |

## Switch centres (for the shell job)

Both keys are C&K PTS645SK43SMTR92LFS. Each is 6.0 × 6.0 mm, 4.3 mm tall above the board top surface (datasheet height code "43"), 2.6 N, SPST, mounted on the top side with rotation 0.

| Key | KiCad page coords (mm) | From board top-left corner, X right / Y down (mm) | From board centre, X right / Y down (mm) | Courtyard (page coords) |
|---|---|---|---|---|
| SW_L1 | (106.30, 91.50) | (6.30, 31.50) | (−23.70, +2.50) | x 101.20–111.39, y 88.06–94.94 |
| SW_R1 | (142.15, 90.00) | (42.15, 30.00) | (+12.15, +1.00) | x 137.06–147.25, y 86.56–93.44 |

The board top-left corner is page (100, 60), the centre is (130, 89), and the board is 60.0 × 58.0 mm. The keys are 35.9 mm apart. Both lie well inside the 68 mm × ~100 mm shell envelope.
Hole centres for reference, page coords: (103.4, 63.4), (156.6, 63.4), (103.4, 114.6), (156.6, 114.6).

## Charge settings

| Item | Part | Value |
|---|---|---|
| Mode | EN2 = VBUS (R50 10k), EN1 = GND | ILIM resistor mode (was USB500 in Rev B) |
| Charge current | R3 = 887 Ω 0.1 % | ICHG = 890 / 887 = **1.00 A** (0.90–1.10 A) = 0.33 C at 3000 mAh |
| Input current limit | R2 = 1.13 kΩ 1 % | 1610 / 1.13k = **1.42 A** (1.31–1.54 A); Rev B 475 mA |
| Safety timer | R49 = 68 kΩ 1 % | **9.1 h** fast charge (6.8–11.3 h), 54 min pre-charge |
| Charge time, 3000 mAh, from empty | model | **≈ 3.9 h** (CC 2.4 h + CV 1.5 h) |
| Timer margin | | 2.31× typical, 1.55× with worst-case part tolerances |
| Unchanged | | 4.2 V charge voltage, BQ29700 protection (4.275 V / 2.8 V / over-current), NTC on TS, thermal regulation, timer enabled |

Full calculations: `RevC_CHANGES.md` §4 and `fab/battery_life_estimate.md` §5b.

## Battery design ceiling (assumption)

The charger is designed for a **1S LiPo of up to 3000 mAh**, with charge current ≤ 0.5 C. This is a placeholder until the shell job picks the final cell.
**If the final cell is smaller than about 2200 mAh, change R3.** At 1.0 A (up to 1.1 A) a smaller cell charges faster than 0.5 C. For example, the Rev B 603450 (1000 mAh) cell would charge at 1 C. Pick R3 = 975 / (0.5 × C) or larger, e.g. 2.0 kΩ for 1000 mAh, and re-check the timer with the battery model.

## Standby power

| State | Rev B | Rev C |
|---|---:|---:|
| ON, deep sleep, radar armed, magnet-on (typical) | 210 µA | **248 µA** (+38 µA: 35 µA EN pull-down through D_TMR, 2.5 µA TMR divider, diode leakage) |
| Same, conservative column | 713 µA | 761 µA |
| ON by chord (HOLD held, magnet off) | — | 241 µA |
| Both keys held | — | +54 µA while pressed |
| OFF | 13.5 µA | 13.5 µA (unchanged) |

Biggest lever: R_EN_PD1 100k → 1M would cut the 35 µA term to 3.5 µA. The spec fixes the value at 100k, so it was not changed.
Daily budget for 3 × 10 min Wi-Fi clips on the 603450 cell: 4.67 days. Standby is ~3 % of the daily energy.

## Not verified — check before ordering or on the first boards

1. **Real switch datasheet.**
   - I did not read the C&K PTS645 PDF; the footprint is KiCad's stock `SW_SPST_PTS645Sx43SMTR92`.
   - Confirm: pin pairs 1–1 and 2–2 joined, SPST contact, land pattern, 4.3 mm height, plunger size.
   - The JLC DB lists only 2,473 in stock (C221871). Alternatives with the same land pattern: PTS645SL50 C221877 (5.0 mm, 1.3 N) or SK50 C221872.
2. **Diode-OR part and new-part availability.**
   - The local JLC DB (a stale snapshot) shows:

     | Part | LCSC | DB class | DB stock |
     |---|---|---|---:|
     | BAT54WS | C7502694 | Preferred | 411k |
     | 887R 0.1 % | C852938 | Extended | 5.5k |
     | 1.13k | C67014 | Extended | 15k |
     | 68k | C36871 | Preferred | — |
     | 470k | C25790 | Preferred | — |
     | PTS645 | C221871 | Extended | 2.5k |
   - Live Basic/Extended status and stock are not confirmed. Upload `fab/assembly/*JLC-BOM.csv` to the JLC quote page to check.
   - Expect roughly +6 extended-line fees (about $3 each at the Rev B Economic rate).
3. **Charge time measurement.** 3.9 h is a CC/CV model, not a measurement. Measure on the real cell through R_MEAS_BAT1, and watch U1 temperature: about 2 W at the start of CC at 1 A gives +89 °C at RθJA 44.5 °C/W. Thermal regulation will stretch the charge. The timer slows down with it, so it will not trip falsely.
4. **Final battery size.** 3000 mAh is a placeholder (see above).
5. **IO12 HOLD in deep sleep.** IO12 is not an LP pin. The board stays on after a chord start only if HOLD is pad-held high through deep sleep. Confirm that the ESP32-S31 supports digital-pad hold in deep sleep. If it does not, move HOLD to an LP pin.
6. **Low-battery sense threshold.** The 0.680 dividers read high only when VSYS ≥ 3.64 V (VIH = 0.75 × 3.3 V). Below that the 2 s chord check fails and the board turns itself off again (fails safe). TMR_SENSE also reads low below 3.64 V.
7. **USB source.** ILIM mode has no VIN-DPM. A 500 mA PC port asked for 1.42 A may current-limit or trip. Only the BQ24075 DPPM (OUT ≥ 4.3 V) backs off the charge. Use a ≥ 1.5 A USB-C charger. CC pins have plain 5.1k Rd; the charger does not read the source's current advertisement.
8. **Pre-charge timer.** A fully over-discharged 3000 mAh cell can need about 46 min of pre-charge against a 41 min minimum timer. A re-plug restarts it.
9. **Firmware (not changed, as instructed).**
   - Rev B firmware does not drive HOLD. Until firmware is updated, a chord powers the board only while both keys are held.
   - Firmware must disable internal pulls on IO0, IO4 and IO13.
   - The TMR3102 latch is bistable. After a chord start with the magnet latch OFF, turning off with the magnet needs an ON pole then an OFF pole. IO13 cannot wake the chip, so a falling TMR_OUT is seen only at the next wake.
10. **JLC placement viewer.** The rotations of the new SOD-323 diodes and the switches are not checked in JLC's viewer. The switch is symmetric. Check the diode cathode bar against KiCad pad 1.
11. **Long high-impedance traces.** WAKE (1M) and WAKE_MID run 60–76 mm across the board to the keys. They are fine for DC, but check for false chord detection under ESD at the keys.

## Folder map

| Path | Contents |
|---|---|
| `ESP32-S31-Vision-Pro-RevC.kicad_pro` / `.kicad_sch` / `.kicad_pcb` + `MCU`, `Storage_USB`, `Sensors` sheets | Rev C project |
| `RevC_CHANGES.md` | every netlist change, part change and charge calculation |
| `reports/` | Rev B + Rev C ERC/DRC reports and `RevB_vs_RevC_ERC_DRC.md` |
| `fab/gerbers.zip` | **JLCPCB PCB upload** (4-layer gerbers + drill) |
| `fab/assembly/ESP32-S31-Vision-Pro-RevC-JLC-BOM.csv`, `-JLC-CPL.csv` | **JLCPCB assembly upload** (U8 ESP32 module hand-placed, as in Rev B) |
| `fab/assembly/*-BOM-full.csv`, `*-positions-all.csv` | full KiCad BOM and positions |
| `fab/docs/` | schematic PDF, assembly PDF, previews, GPIO audit, reports |
| `fab/battery_life_estimate.md` | Rev C power model (`pcb_build/scripts/battery_model.py`) |
| `ESP32-S31-Vision-Pro-RevC-fab.zip` | everything in `fab/` in one archive |
| `pcb_build/revc/scripts/` | re-runnable build (`run_revc.sh`, `export_revc.sh`) |
| `ref_RevB/` | Rev B reports and docs for comparison |
